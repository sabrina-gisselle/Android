package com.example.sabrina.hsvcolorpicker;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.support.v4.content.CursorLoader;
import android.database.Cursor;
import android.support.v4.app.LoaderManager;
import android.os.Bundle;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.sabrina.hsvcolorpicker.contentprovider.ColorContentProvider;
import com.example.sabrina.hsvcolorpicker.db.ColorDBHelper;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;
import java.util.Map;

public class ListFragmentName extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>  {

    private TaskCursorAdapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_main, container, false);

        final ListView listView = (ListView) rootView.findViewById(R.id.list);


        /*

        Cursor mCursor = getActivity().getContentResolver().query(
                ColorContentProvider.CONTENT_URI,
                TaskCursorAdapter.PROJECTION,   // The columns to return for each row
                SELECTION,
                SELECTION_ARGS,
                null);
*/
        //getLoaderManager().initLoader(0, null, this);

        ColorDBHelper myDbHelper = new ColorDBHelper(rootView.getContext());
        Cursor cursor = myDbHelper.findNamesInRange(HSVColor.getHueLeft(), HSVColor.getHueRight(), HSVColor.getSaturation(), HSVColor.getValue(), .1f);

        mAdapter = new TaskCursorAdapter( getActivity(), // context
                cursor, // cursor
                0     // flags
        );

        if(listView != null) {
            listView.setAdapter(mAdapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {
                    Map<String, String> extra = TaskCursorAdapter.getExtraInfo(view);
                    String t = extra.toString();
                    Toast.makeText(rootView.getContext(), t, Toast.LENGTH_LONG).show();
                }
            });
        }
        return rootView;
    }

   /* @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        String SELECTION = "Name=?";
        List<String> selectionArgs = new ArrayList<String>();
        selectionArgs.add("Aero");

        if (bundle != null && bundle.containsKey("query")) {
            SELECTION += " AND columnTitle LIKE ?";
            selectionArgs.add(bundle.getString("query") + "%");
        }

        final String[] SELECTION_ARGS = new String[selectionArgs.size()];
        selectionArgs.toArray(SELECTION_ARGS);

        Cursor c = null;
        c = activity.getApplicationContext().getContentResolver().query(
                ColorContentProvider.CONTENT_URI,
                TaskCursorAdapter.PROJECTION,
                null,
                null,
                null);
        getActivity().startManagingCursor(c);
        c.moveToFirst();
        if(c == null){
            String t = "why?";
        }
    }*/
    /****************************************
     ** LoaderManager.LoaderCallbacks
     *****************************************/

    // creates a new loader after the initLoader () call
    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        /*CursorLoader cursorLoader
                = new CursorLoader( getActivity(),
                ColorContentProvider.CONTENT_URI,
                TaskCursorAdapter.PROJECTION,
                null,
                null,
                null );
                //TaskCursorAdapter.ORDER_BY );

        return cursorLoader;
*/
        String SELECTION = "Name=?";
        List<String> selectionArgs = new ArrayList<String>();
        selectionArgs.add("Aero");

        /*if (bundle != null && bundle.containsKey("query")) {
            SELECTION += " AND columnTitle LIKE ?";
            selectionArgs.add(bundle.getString("query") + "%");
        }*/

        final String[] SELECTION_ARGS = new String[selectionArgs.size()];
        selectionArgs.toArray(SELECTION_ARGS);

        CursorLoader cursorLoader
                = new CursorLoader( getActivity(),
                ColorContentProvider.CONTENT_URI,
                TaskCursorAdapter.PROJECTION,
                SELECTION,
                SELECTION_ARGS, null);

        return cursorLoader;

    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // data is not available anymore, delete reference
        mAdapter.swapCursor(null);
    }

}