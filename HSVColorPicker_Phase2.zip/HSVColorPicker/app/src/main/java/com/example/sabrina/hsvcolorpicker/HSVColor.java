package com.example.sabrina.hsvcolorpicker;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Sabrina on 4/15/2015.
 */
public class HSVColor {
    public static final float difference = 30f;

    private static float leftHue = 0.0f;
    private static float rightHue = 0.0f;
    private static float saturation = 1.0f;
    private static float value = 1.0f;

    private float[] leftHsv = {     leftHue,        // float: [0.0f, 360.0f]
                                    saturation,     // float: [0.0f, 1.0f]
                                    value           // float: [0.0f, 1.0f]
    };

    private float[] rightHsv = {    rightHue,        // float: [0.0f, 360.0f]
                                    saturation,     // float: [0.0f, 1.0f]
                                    value           // float: [0.0f, 1.0f]
    };

    private HSVColor(float aHueLeft, float aHueRight, float aSaturation, float aValue) {
        leftHue = aHueLeft;
        rightHue = aHueRight;
        saturation = aSaturation;
        value = aValue;
        leftHsv = new float[]{leftHue, saturation, value};
        rightHsv = new float[]{rightHue, saturation, value};
    }

    static public List<GradientDrawable> populateHueList() {
        ArrayList<GradientDrawable> list = new ArrayList<>( );
        float times = 360/difference;
        float startingLeft = 360f - difference/2;
        float startingRight = difference/2;

        for (int i = 0; i < times; ++i) {
            HSVColor hsvColor = new HSVColor((startingLeft+difference*i)%360, (startingRight+difference*i)%360, 1f, 1f);
            int colorLeft = Color.HSVToColor(hsvColor.leftHsv);
            int colorRight = Color.HSVToColor(hsvColor.rightHsv);

            list.add(new GradientDrawable( GradientDrawable.Orientation.LEFT_RIGHT, new int[] { colorLeft, colorRight } ));
        }
        return Collections.unmodifiableList(list);
    }

    static public List<GradientDrawable> populateSaturationList(float aHueLeft, float aHueRight) {
        ArrayList<GradientDrawable> list = new ArrayList<>( );

        for (float i = 1.0f; i >= 0f ; i = i - 0.1f) {
            HSVColor hsvColor = new HSVColor(aHueLeft, aHueRight, i, 1f);
            int colorLeft = Color.HSVToColor(hsvColor.leftHsv);
            int colorRight = Color.HSVToColor(hsvColor.rightHsv);

            list.add(new GradientDrawable( GradientDrawable.Orientation.LEFT_RIGHT, new int[] { colorLeft, colorRight } ));
        }
        return Collections.unmodifiableList(list);
    }

    static public List<GradientDrawable> populateValueList(float aHueLeft, float aHueRight, float aSaturation) {
        ArrayList<GradientDrawable> list = new ArrayList<>( );

        for (float i = 1.0f; i >= 0f ; i = i - 0.1f) {
            HSVColor hsvColor = new HSVColor(aHueLeft, aHueRight, aSaturation, i);
            int colorLeft = Color.HSVToColor(hsvColor.leftHsv);
            int colorRight = Color.HSVToColor(hsvColor.rightHsv);

            list.add(new GradientDrawable( GradientDrawable.Orientation.LEFT_RIGHT, new int[] { colorLeft, colorRight } ));
        }
        return Collections.unmodifiableList(list);
    }

    static public List<GradientDrawable> getHSV() {
        ArrayList<GradientDrawable> list = new ArrayList<>( );

        HSVColor hsvColor = new HSVColor(leftHue, rightHue, saturation, value);
        int colorLeft = Color.HSVToColor(hsvColor.leftHsv);
        int colorRight = Color.HSVToColor(hsvColor.rightHsv);

        list.add(new GradientDrawable( GradientDrawable.Orientation.LEFT_RIGHT, new int[] { colorLeft, colorRight } ));

        return Collections.unmodifiableList(list);
    }

    public static float getLeftHueByPosition(int position) {
        return (360f - difference/2 + position*30)%360f;
    }

    public static float getRightHueByPosition(int position) {
        return (difference/2 + position*30)%360f;
    }

    public static void setHueLeft(float settingHue){
        leftHue = settingHue;
    }

    public static float getHueLeft(){
        return leftHue;
    }

    public static void setHueRight(float settingHue){
        rightHue = settingHue;
    }

    public static float getHueRight(){
        return rightHue;
    }

    public static void setSaturation (float settingSaturation){
        saturation = settingSaturation;
    }

    public static float getSaturation(){
        return saturation;
    }
    public static void setValue (float settingValue){
        value = settingValue;
    }

    public static float getValue(){
        return value;
    }
}
