package com.example.sabrina.hsvcolorpicker.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;

public class ColorDBHelper extends SQLiteOpenHelper {

    private static String DATABASE_PATH = "/data/data/com.example.sabrina.hsvcolorpicker/databases/";
    private static final String DATABASE_NAME = "ColorDB.sqlite";
    private static final int DATABASE_VERSION = 1;
    private SQLiteDatabase mDatabase;
    private final Context myContext;

    public ColorDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        myContext = context;
    }

    public void createDatabase() throws IOException {

        boolean dbExist = checkDatabase();

        if(dbExist){
            // do nothing - database already exist
        }else{

            // By calling this method an empty database will be created into the default system path
            // of your application so we are gonna be able to overwrite that database with our database.
            this.getReadableDatabase();

            try {

                copyDatabase();

            } catch (IOException e) {

                throw new Error("Error copying database");

            }
        }

    }

    private boolean checkDatabase(){

        SQLiteDatabase checkDB = null;

        try{
            String myPath = DATABASE_PATH + DATABASE_NAME;
            checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY);

        }catch(SQLiteException e){

            //database doesn't exist yet.

        }

        if(checkDB != null){

            checkDB.close();

        }

        return checkDB != null ? true : false;
    }

    private void copyDatabase() throws IOException{

        //Open your local db as the input stream
        InputStream myInput = myContext.getAssets().open(DATABASE_NAME);

        // Path to the just created empty db
        String outFileName = DATABASE_PATH + DATABASE_NAME;

        //Open the empty db as the output stream
        OutputStream myOutput = new FileOutputStream(outFileName);

        //transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer))>0){
            myOutput.write(buffer, 0, length);
        }

        //Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();
    }

    public void openDatabase() throws SQLException {

        //Open the database
        String myPath = DATABASE_PATH + DATABASE_NAME;
        mDatabase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY);
    }

    public boolean tableExists(String tableName, boolean openDb) {
        if(openDb) {
            if(mDatabase == null || !mDatabase.isOpen()) {
                mDatabase = getReadableDatabase();
            }

            if(!mDatabase.isReadOnly()) {
                mDatabase.close();
                mDatabase = getReadableDatabase();
            }
        }

        Cursor cursor = mDatabase.rawQuery("select * from Color where Hue >= 100;", null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                cursor.close();
                return true;
            }
            cursor.close();
        }
        return false;
    }

    public Cursor findNamesInRange(float leftHue, float rightHue, float saturation, float value, float delta){
        float leftSaturation = saturation - delta;
        float rightSaturation = saturation + delta;
        float leftValue = value - delta;
        float rightValue = value + delta;
        mDatabase = getReadableDatabase();
        Cursor cursor = mDatabase.rawQuery("select * from Color where  Hue >= "
                        + leftHue + " and Hue <= " + rightHue
                        + " and Saturation >= " + leftSaturation
                        + " and Saturation <= " + rightSaturation
                        + " and Value >= " + leftValue
                        + " and Value <= " + rightValue
                        + ";",
                null);

        return cursor;
    }
    @Override
    public synchronized void close() {

        if(mDatabase != null)
            mDatabase.close();

        super.close();

    }

    @Override
    public void onCreate( SQLiteDatabase database ) { }

    @Override
    public void onUpgrade( SQLiteDatabase database,
                           int oldVersion,
                           int newVersion) { }
}

