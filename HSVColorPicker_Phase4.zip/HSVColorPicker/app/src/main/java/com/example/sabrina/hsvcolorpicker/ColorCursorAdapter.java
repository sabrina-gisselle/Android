package com.example.sabrina.hsvcolorpicker;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sabrina.hsvcolorpicker.db.ColorTable;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


public class ColorCursorAdapter extends CursorAdapter {

    // Fields from the database (projection)
    // Must include the _id column for the adapter to work
    static private final int NAME = 0;
    static private final int HEX = 1;
    static private final int HUE = 2;
    static private final int SATURATION = 3;
    static private final int VALUE = 4;
    static private final int ID = 5;

    static public final String[] PROJECTION
            = new String[] {
            ColorTable.COLUMN_NAME,
            ColorTable.COLUMN_HEX,
            ColorTable.COLUMN_HUE,
            ColorTable.COLUMN_SATURATION,
            ColorTable.COLUMN_VALUE,
            ColorTable.COLUMN_ID
    };

    static public int currentOrder = -1;

    static public final String[] ORDER_BY
            = new String[]{
            ColorTable.COLUMN_HUE + "," + ColorTable.COLUMN_SATURATION + "," + ColorTable.COLUMN_VALUE,
            ColorTable.COLUMN_HUE + "," + ColorTable.COLUMN_VALUE + "," + ColorTable.COLUMN_SATURATION,
            ColorTable.COLUMN_SATURATION + "," + ColorTable.COLUMN_HUE + "," + ColorTable.COLUMN_VALUE,
            ColorTable.COLUMN_SATURATION + "," + ColorTable.COLUMN_VALUE + "," + ColorTable.COLUMN_HUE,
            ColorTable.COLUMN_VALUE + "," + ColorTable.COLUMN_HUE + "," + ColorTable.COLUMN_SATURATION,
            ColorTable.COLUMN_VALUE + "," + ColorTable.COLUMN_SATURATION + "," + ColorTable.COLUMN_HUE
    };
    /*
    static private final int[] PRIORITY_COLOR;
    static {
        PRIORITY_COLOR = new int[] {
                Color.parseColor( "#ffeeee" ),
                Color.parseColor( "#ffffee" ),
                Color.parseColor( "#eeffee" ),
                Color.parseColor( "#eeeeff" )
        };
    }
*/

    static private class ViewHolder {
        TextView label;
        Map<String, String> extraInfo;
    }

    private LayoutInflater mInflater;

    public ColorCursorAdapter(Context context, Cursor cursor, int flags) {
        super(context, cursor, flags);

        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {

        View row = mInflater.inflate(R.layout.color_row, parent, false);

        // cache the row's Views in a ViewHolder
        ViewHolder viewHolder = new ViewHolder();
        viewHolder.label = (TextView) row.findViewById( R.id.label );
        row.setTag( viewHolder );

        return row;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        ViewHolder viewHolder = updateViewHolderValues(view, cursor);
        //decorateView( viewHolder, cursor );
    }

    private ViewHolder updateViewHolderValues(View view, Cursor cursor) {
        ViewHolder viewHolder = (ViewHolder) view.getTag();

        viewHolder.label.setText( cursor.getString( NAME ) );
        viewHolder.label.setBackgroundColor(Color.parseColor(cursor.getString(HEX)));
        viewHolder.extraInfo = new HashMap<>();

        viewHolder.extraInfo.put("name", cursor.getString(NAME));
        viewHolder.extraInfo.put( "hue", Integer.toString(cursor.getInt(HUE)));
        viewHolder.extraInfo.put( "saturation", Float.toString(cursor.getFloat(SATURATION)));
        viewHolder.extraInfo.put( "value", Float.toString(cursor.getFloat(VALUE)));
        viewHolder.extraInfo.put( "hex", cursor.getString(HEX));
        return viewHolder;
    }

    public static Map<String, String> getExtraInfo( View view ) {
        ViewHolder viewHolder = (ViewHolder) view.getTag();
        return viewHolder.extraInfo;
    }

    /*private void decorateView( ViewHolder task, Cursor cursor ) {
        // set the text styling based on the the completion status
        if ( task.isCompleted ) {
            // strike-thru the text of isCompleted items
            task.label.setPaintFlags(
                    task.label.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG );

        } else {
            // clear the strike-thru flag (may have been set if view is recycled)
            task.label.setPaintFlags(
                    task.label.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG );
        }

        // set the background color based on the priority
        /*int priority = cursor.getInt( PRIORITY );
        if ( 0 <= priority && priority <= 2 )
            task.label.setBackgroundColor( PRIORITY_COLOR[priority] );
    }


    /*public static int toggleCompleted( View view ) {

        ViewHolder viewHolder = (ViewHolder) view.getTag();
        viewHolder.isCompleted = ! viewHolder.isCompleted;

        return viewHolder.isCompleted ? 1 : 0;
    }

    public static boolean isTaskCompleted( View view ) {
        ViewHolder viewHolder = (ViewHolder) view.getTag();
        return viewHolder.isCompleted;
    }*/
}
