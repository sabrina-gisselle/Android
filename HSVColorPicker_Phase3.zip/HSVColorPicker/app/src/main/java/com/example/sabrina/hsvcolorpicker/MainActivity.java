package com.example.sabrina.hsvcolorpicker;

import android.app.AlertDialog;
import android.support.v4.app.Fragment;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.sabrina.hsvcolorpicker.db.ColorDBHelper;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;


public class MainActivity extends ActionBarActivity {
    static final private String CURRENT_SORTED_ORDER = "sortedOrder";

    private int mEntry = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mEntry = getPreferences(MODE_PRIVATE ).getInt(CURRENT_SORTED_ORDER, -1);
        ColorCursorAdapter.currentOrder = mEntry;

        ColorDBHelper myDbHelper = new ColorDBHelper(this);

        try {

            myDbHelper.createDatabase();

        } catch (IOException ioe) {

            throw new Error("Unable to create database");

        }

        try {

            myDbHelper.openDatabase();

        }catch(SQLException sqle){

            try {
                throw sqle;
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, new ListFragmentHue())
                    .commit();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void sortingButtonHandler(View view){

        AlertDialog levelDialog;

        final CharSequence[] items = {"Hue, Saturation, Value",
                "Hue, Value, Saturation",
                "Saturation, Hue, Value",
                "Saturation, Value, Hue",
                "Value, Hue, Saturation",
                "Value, Saturation, Hue"};

        // Creating and Building the Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.select_sorting_order));

        builder.setSingleChoiceItems(items, mEntry, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item) {
                mEntry = item;
                ColorCursorAdapter.currentOrder = item;
                SharedPreferences.Editor editor = getPreferences(MODE_PRIVATE).edit();
                editor.putInt(CURRENT_SORTED_ORDER, item);
                editor.commit();

                dialog.dismiss();

                List<Fragment> fragments = getSupportFragmentManager().getFragments();
                ListFragmentName fragment = (ListFragmentName)fragments.get(fragments.size() - 1);

                fragment.getFragmentManager().beginTransaction().replace(R.id.container, new ListFragmentName(), null).addToBackStack(null).commit();
            }
        });
        levelDialog = builder.create();
        levelDialog.show();
    }
}
